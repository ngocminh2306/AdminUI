import { Component } from '@angular/core';

@Component({
  selector: 'ngx-block-level-buttons',
  templateUrl: './block-level-buttons.component.html',
})
export class BlockLevelButtonsComponent {
}
