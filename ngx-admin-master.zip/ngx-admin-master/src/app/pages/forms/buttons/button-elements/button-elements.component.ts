import { Component } from '@angular/core';

@Component({
  selector: 'ngx-button-elements',
  styleUrls: ['./button-elements.component.scss'],
  templateUrl: './button-elements.component.html',
})
export class ButtonElementsComponent {

  onClick() {
  }
}
