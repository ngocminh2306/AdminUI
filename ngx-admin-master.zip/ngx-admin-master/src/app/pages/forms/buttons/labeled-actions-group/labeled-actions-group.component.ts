import { Component } from '@angular/core';

@Component({
  selector: 'ngx-labeled-actions-group',
  styleUrls: ['./labeled-actions-group.component.scss'],
  templateUrl: './labeled-actions-group.component.html',
})
export class LabeledActionsGroupComponent {
}
